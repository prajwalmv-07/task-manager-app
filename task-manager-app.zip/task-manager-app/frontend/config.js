// Point these at your deployed backend URL, e.g. "https://your-api.onrender.com"
const API_BASE = "http://localhost:5000/api";
const SOCKET_URL = "http://localhost:5000";
