const token = localStorage.getItem("tf_token");
const user = JSON.parse(localStorage.getItem("tf_user") || "null");

if (!token || !user) {
  window.location.href = "login.html";
}

document.getElementById("user-name").textContent = user.name;

document.getElementById("logout-btn").addEventListener("click", () => {
  localStorage.removeItem("tf_token");
  localStorage.removeItem("tf_user");
  window.location.href = "login.html";
});

let tasks = [];

async function apiFetch(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers || {})
    }
  });
  if (res.status === 401) {
    localStorage.removeItem("tf_token");
    window.location.href = "login.html";
    return null;
  }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function escapeHtml(str = "") {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function render() {
  const columns = { todo: [], "in-progress": [], done: [] };
  tasks.forEach((t) => columns[t.status]?.push(t));

  Object.entries(columns).forEach(([status, list]) => {
    document.getElementById(`count-${status}`).textContent = list.length;
    const container = document.getElementById(`list-${status}`);

    if (!list.length) {
      container.innerHTML = `<p class="empty-hint">No tasks here</p>`;
      return;
    }

    container.innerHTML = list
      .map((t) => {
        const due = t.dueDate ? new Date(t.dueDate).toLocaleDateString() : "";
        return `
          <article class="task-card priority-${t.priority}" data-id="${t._id}">
            <h4>${escapeHtml(t.title)}</h4>
            ${t.description ? `<p>${escapeHtml(t.description)}</p>` : ""}
            <div class="task-meta">
              <span class="priority-tag">${t.priority}</span>
              ${due ? `<span class="due-tag">Due ${due}</span>` : ""}
            </div>
            <div class="task-actions">
              ${statusButtons(t)}
              <button class="delete-btn" data-action="delete" data-id="${t._id}">Delete</button>
            </div>
          </article>`;
      })
      .join("");
  });
}

function statusButtons(task) {
  const order = ["todo", "in-progress", "done"];
  const idx = order.indexOf(task.status);
  const buttons = [];
  if (idx > 0) {
    buttons.push(
      `<button data-action="move" data-id="${task._id}" data-status="${order[idx - 1]}">← ${order[idx - 1]}</button>`
    );
  }
  if (idx < order.length - 1) {
    buttons.push(
      `<button data-action="move" data-id="${task._id}" data-status="${order[idx + 1]}">${order[idx + 1]} →</button>`
    );
  }
  return buttons.join("");
}

document.querySelector(".board").addEventListener("click", async (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const { action, id, status } = btn.dataset;

  try {
    if (action === "delete") {
      await apiFetch(`/tasks/${id}`, { method: "DELETE" });
    } else if (action === "move") {
      await apiFetch(`/tasks/${id}`, {
        method: "PUT",
        body: JSON.stringify({ status })
      });
    }
  } catch (err) {
    alert(err.message);
  }
});

document.getElementById("task-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("task-title").value.trim();
  const description = document.getElementById("task-desc").value.trim();
  const priority = document.getElementById("task-priority").value;
  const dueDate = document.getElementById("task-due").value || undefined;

  try {
    await apiFetch("/tasks", {
      method: "POST",
      body: JSON.stringify({ title, description, priority, dueDate })
    });
    e.target.reset();
    document.getElementById("task-priority").value = "medium";
  } catch (err) {
    alert(err.message);
  }
});

async function loadTasks() {
  try {
    tasks = await apiFetch("/tasks");
    render();
  } catch (err) {
    console.error(err);
  }
}

// Real-time sync: the server pushes task:created / task:updated / task:deleted
// events to this user's room, so the board updates without a page refresh —
// including across multiple open tabs/devices.
const socket = io(SOCKET_URL, { auth: { token } });

socket.on("task:created", (task) => {
  tasks.unshift(task);
  render();
});

socket.on("task:updated", (updated) => {
  tasks = tasks.map((t) => (t._id === updated._id ? updated : t));
  render();
});

socket.on("task:deleted", ({ id }) => {
  tasks = tasks.filter((t) => t._id !== id);
  render();
});

loadTasks();
