# TaskFlow — Task Management Application

Full-stack task manager: static HTML/CSS/JS frontend, an Express + Socket.IO
backend, JWT authentication, and MongoDB for storage.

```
task-manager-app/
├── frontend/           Static site — deploy to Netlify or Vercel
│   ├── login.html
│   ├── index.html       (task board)
│   ├── config.js         set your backend URL here
│   ├── auth.js
│   ├── app.js
│   └── style.css
└── backend/             Express + Socket.IO API — deploy to Render/Railway/Heroku
    ├── server.js
    ├── models/
    │   ├── User.js
    │   └── Task.js
    ├── middleware/auth.js
    └── routes/
        ├── auth.js
        └── tasks.js
```

## Features

- **Auth**: register/login with hashed passwords (bcrypt) and JWT sessions.
- **Tasks**: create, edit (via status move), delete — each task scoped to its owner.
- **Real-time**: Socket.IO pushes `task:created` / `task:updated` / `task:deleted`
  to the signed-in user's own room, so the board updates live across open tabs.
- **Responsive**: three-column board collapses to a single column on narrow screens.

## 1. Run the backend locally

```bash
cd backend
npm install
cp .env.example .env      # then edit .env — set MONGODB_URI and JWT_SECRET
npm run dev                # or: npm start
```

Starts the API + Socket.IO server at `http://localhost:5000`. Health check:
`GET /api/health`.

Get a MongoDB URI either by running MongoDB locally, or with a free cluster
at mongodb.com/atlas.

## 2. Run the frontend locally

Open `frontend/login.html` in a browser, or serve the folder (e.g. VS Code's
"Live Server"). It talks to the API/socket URLs set in `frontend/config.js` —
by default `http://localhost:5000`.

Create an account on the sign-up tab, then you'll land on the task board.

## 3. Deploy

**Backend (Render, Railway, or Heroku):**
1. Push this repo to GitHub.
2. Create a new Web Service pointing at the `backend/` folder.
3. Build command: `npm install`. Start command: `npm start`.
4. Set environment variables: `MONGODB_URI`, `JWT_SECRET`, `CLIENT_ORIGIN`
   (your frontend's deployed URL).

**Frontend (Vercel or Netlify):**
1. Before deploying, update `API_BASE` and `SOCKET_URL` in
   `frontend/config.js` to your live backend URL
   (e.g. `https://your-app.onrender.com` / `.../api`).
2. Create a new project pointing at the `frontend/` folder as the root —
   no build step needed, it's static files.

Once both are live, open the frontend URL, register an account, and confirm
tasks can be created, moved between columns, and deleted — and that changes
appear instantly if you open the board in two tabs at once.
