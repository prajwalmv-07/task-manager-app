const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const requireAuth = require('../middleware/auth');

router.use(requireAuth);

// GET /api/tasks - list the current user's tasks
router.get('/', async (req, res) => {
  try {
    const tasks = await Task.find({ owner: req.userId }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tasks', details: err.message });
  }
});

// POST /api/tasks - create a task
router.post('/', async (req, res) => {
  try {
    const { title, description, status, priority, dueDate } = req.body;
    if (!title) return res.status(400).json({ error: 'title is required' });

    const task = await Task.create({
      owner: req.userId,
      title,
      description,
      status,
      priority,
      dueDate
    });

    req.app.get('io').to(`user:${req.userId}`).emit('task:created', task);
    res.status(201).json(task);
  } catch (err) {
    res.status(400).json({ error: 'Failed to create task', details: err.message });
  }
});

// PUT /api/tasks/:id - update a task (edit fields, change status, etc.)
router.put('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, owner: req.userId },
      req.body,
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ error: 'Task not found' });

    req.app.get('io').to(`user:${req.userId}`).emit('task:updated', task);
    res.json(task);
  } catch (err) {
    res.status(400).json({ error: 'Failed to update task', details: err.message });
  }
});

// DELETE /api/tasks/:id - remove a task
router.delete('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, owner: req.userId });
    if (!task) return res.status(404).json({ error: 'Task not found' });

    req.app.get('io').to(`user:${req.userId}`).emit('task:deleted', { id: req.params.id });
    res.json({ message: 'Task deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete task', details: err.message });
  }
});

module.exports = router;
