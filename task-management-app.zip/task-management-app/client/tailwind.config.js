/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef4ff',
          100: '#dbe6fe',
          200: '#bdd1fe',
          300: '#8fb2fc',
          400: '#5b8bf8',
          500: '#3565f0',
          600: '#2247e3',
          700: '#1d38c6',
          800: '#1e32a0',
          900: '#1e2f7e',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px 0 rgba(16, 24, 40, 0.08), 0 1px 2px -1px rgba(16, 24, 40, 0.08)',
        cardHover: '0 4px 12px -2px rgba(16, 24, 40, 0.12)',
      },
    },
  },
  plugins: [],
};
