import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initials = user?.name
    ?.split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/dashboard" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-600 text-white font-bold">
            T
          </span>
          <span className="text-lg font-bold text-slate-900">TaskFlow</span>
        </Link>

        <div className="hidden items-center gap-3 sm:flex">
          <span className="text-sm text-slate-500">
            Hi, <span className="font-semibold text-slate-800">{user?.name}</span>
          </span>
          <button onClick={handleLogout} className="btn-secondary">
            Logout
          </button>
        </div>

        {/* Mobile menu button */}
        <button
          className="sm:hidden flex h-9 w-9 items-center justify-center rounded-lg border border-slate-300 text-slate-600"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {menuOpen ? '✕' : '☰'}
        </button>
      </div>

      {menuOpen && (
        <div className="sm:hidden border-t border-slate-200 bg-white px-4 py-3">
          <div className="mb-3 flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-700">
              {initials}
            </span>
            <span className="text-sm font-medium text-slate-700">{user?.name}</span>
          </div>
          <button onClick={handleLogout} className="btn-secondary w-full">
            Logout
          </button>
        </div>
      )}
    </header>
  );
};

export default Navbar;
