const statusStyles = {
  Pending: 'bg-slate-100 text-slate-700',
  'In Progress': 'bg-blue-100 text-blue-700',
  Completed: 'bg-emerald-100 text-emerald-700',
};

const priorityStyles = {
  Low: 'bg-slate-100 text-slate-600 border-slate-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  High: 'bg-red-50 text-red-700 border-red-200',
};

const formatDate = (dateStr) =>
  new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

const TaskCard = ({ task, onEdit, onDelete, onStatusChange }) => {
  const isOverdue = task.status !== 'Completed' && new Date(task.dueDate) < new Date();

  return (
    <div className="card flex flex-col gap-3 p-5 transition-shadow hover:shadow-cardHover">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-semibold text-slate-900 line-clamp-2">{task.title}</h3>
        <span className={`shrink-0 rounded-full border px-2 py-0.5 text-xs font-medium ${priorityStyles[task.priority]}`}>
          {task.priority}
        </span>
      </div>

      {task.description && (
        <p className="text-sm text-slate-500 line-clamp-2">{task.description}</p>
      )}

      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className={`rounded-full px-2.5 py-1 font-medium ${statusStyles[task.status]}`}>{task.status}</span>
        <span className={`rounded-full px-2.5 py-1 font-medium ${isOverdue ? 'bg-red-100 text-red-700' : 'bg-slate-50 text-slate-500'}`}>
          {isOverdue ? '⚠ Overdue · ' : 'Due '}
          {formatDate(task.dueDate)}
        </span>
      </div>

      <div className="mt-1 flex items-center justify-between gap-2 border-t border-slate-100 pt-3">
        <select
          value={task.status}
          onChange={(e) => onStatusChange(task._id, e.target.value)}
          className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-600 focus:border-brand-500 focus:ring-1 focus:ring-brand-500"
        >
          <option value="Pending">Pending</option>
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
        </select>

        <div className="flex gap-2">
          <button
            onClick={() => onEdit(task)}
            className="rounded-md px-2 py-1 text-xs font-semibold text-brand-600 hover:bg-brand-50"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(task)}
            className="rounded-md px-2 py-1 text-xs font-semibold text-red-600 hover:bg-red-50"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
