const Loader = ({ label = 'Loading...', size = 'md' }) => {
  const sizes = { sm: 'h-4 w-4 border-2', md: 'h-8 w-8 border-2', lg: 'h-12 w-12 border-[3px]' };

  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10 text-slate-500">
      <div
        className={`${sizes[size]} animate-spin rounded-full border-brand-500 border-t-transparent`}
        role="status"
        aria-label="Loading"
      />
      {label && <p className="text-sm">{label}</p>}
    </div>
  );
};

export default Loader;
