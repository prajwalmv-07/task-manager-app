import { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import Navbar from '../components/Navbar';
import StatCard from '../components/StatCard';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import ConfirmDialog from '../components/ConfirmDialog';
import Loader from '../components/Loader';
import { useSocket } from '../hooks/useSocket';
import {
  fetchTasks,
  fetchTaskStats,
  createTask as apiCreateTask,
  updateTask as apiUpdateTask,
  deleteTask as apiDeleteTask,
} from '../services/api';

const Dashboard = () => {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ total: 0, pending: 0, inProgress: 0, completed: 0, overdue: 0 });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [sortBy, setSortBy] = useState('dueDate');
  const [order, setOrder] = useState('asc');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [tasksRes, statsRes] = await Promise.all([
        fetchTasks({ search, status: statusFilter, priority: priorityFilter, sortBy, order }),
        fetchTaskStats(),
      ]);
      setTasks(tasksRes.data.tasks);
      setStats(statsRes.data.stats);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter, priorityFilter, sortBy, order]);

  useEffect(() => {
    const debounce = setTimeout(loadData, 300);
    return () => clearTimeout(debounce);
  }, [loadData]);

  // Real-time updates via Socket.IO (multi-tab / multi-device sync)
  useSocket({
    'task:created': () => loadData(),
    'task:updated': () => loadData(),
    'task:deleted': () => loadData(),
  });

  const openCreateModal = () => {
    setEditingTask(null);
    setModalOpen(true);
  };

  const openEditModal = (task) => {
    setEditingTask(task);
    setModalOpen(true);
  };

  const handleSubmitTask = async (formData) => {
    setSubmitting(true);
    try {
      if (editingTask) {
        await apiUpdateTask(editingTask._id, formData);
        toast.success('Task updated');
      } else {
        await apiCreateTask(formData);
        toast.success('Task created');
      }
      setModalOpen(false);
      loadData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (id, status) => {
    try {
      await apiUpdateTask(id, { status });
      toast.success('Status updated');
      loadData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update status');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      await apiDeleteTask(deleteTarget._id);
      toast.success('Task deleted');
      setDeleteTarget(null);
      loadData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete task');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Task Dashboard</h1>
            <p className="text-sm text-slate-500">Track, organize, and manage all your tasks in one place.</p>
          </div>
          <button onClick={openCreateModal} className="btn-primary">
            + New Task
          </button>
        </div>

        {/* Stats */}
        <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          <StatCard label="Total Tasks" value={stats.total} icon="📋" color="slate" />
          <StatCard label="Pending" value={stats.pending} icon="⏳" color="amber" />
          <StatCard label="In Progress" value={stats.inProgress} icon="🔄" color="blue" />
          <StatCard label="Completed" value={stats.completed} icon="✅" color="green" />
          <StatCard label="Overdue" value={stats.overdue} icon="⚠" color="red" />
        </div>

        {/* Filters */}
        <div className="card mb-6 flex flex-col gap-3 p-4 sm:flex-row sm:flex-wrap sm:items-center">
          <input
            type="text"
            placeholder="Search tasks by title or description..."
            className="input sm:flex-1 sm:min-w-[220px]"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select className="input sm:w-auto" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="All">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>

          <select className="input sm:w-auto" value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
            <option value="All">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          <select className="input sm:w-auto" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="dueDate">Sort: Due Date</option>
            <option value="priority">Sort: Priority</option>
            <option value="createdAt">Sort: Created</option>
            <option value="title">Sort: Title</option>
          </select>

          <button
            className="btn-secondary sm:w-auto"
            onClick={() => setOrder((o) => (o === 'asc' ? 'desc' : 'asc'))}
            title="Toggle sort order"
          >
            {order === 'asc' ? '↑ Asc' : '↓ Desc'}
          </button>
        </div>

        {/* Task list */}
        {loading ? (
          <Loader label="Loading your tasks..." />
        ) : tasks.length === 0 ? (
          <div className="card flex flex-col items-center justify-center gap-2 p-14 text-center">
            <span className="text-4xl">🗒️</span>
            <h3 className="text-base font-semibold text-slate-800">No tasks found</h3>
            <p className="max-w-sm text-sm text-slate-500">
              {search || statusFilter !== 'All' || priorityFilter !== 'All'
                ? 'Try adjusting your search or filters to see more tasks.'
                : 'Get started by creating your first task.'}
            </p>
            {!search && statusFilter === 'All' && priorityFilter === 'All' && (
              <button onClick={openCreateModal} className="btn-primary mt-2">
                + Create your first task
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {tasks.map((task) => (
              <TaskCard
                key={task._id}
                task={task}
                onEdit={openEditModal}
                onDelete={setDeleteTarget}
                onStatusChange={handleStatusChange}
              />
            ))}
          </div>
        )}
      </main>

      <TaskModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleSubmitTask}
        initialData={editingTask}
        submitting={submitting}
      />

      <ConfirmDialog
        isOpen={!!deleteTarget}
        title="Delete this task?"
        message={`"${deleteTarget?.title}" will be permanently removed. This action cannot be undone.`}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
        loading={submitting}
      />
    </div>
  );
};

export default Dashboard;
