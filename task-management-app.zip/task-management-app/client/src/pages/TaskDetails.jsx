import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import Navbar from '../components/Navbar';
import Loader from '../components/Loader';
import TaskModal from '../components/TaskModal';
import ConfirmDialog from '../components/ConfirmDialog';
import { fetchTask, updateTask, deleteTask } from '../services/api';

const statusStyles = {
  Pending: 'bg-slate-100 text-slate-700',
  'In Progress': 'bg-blue-100 text-blue-700',
  Completed: 'bg-emerald-100 text-emerald-700',
};

const priorityStyles = {
  Low: 'bg-slate-100 text-slate-600 border-slate-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  High: 'bg-red-50 text-red-700 border-red-200',
};

const TaskDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const loadTask = async () => {
    setLoading(true);
    try {
      const { data } = await fetchTask(id);
      setTask(data.task);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Task not found');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTask();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleUpdate = async (formData) => {
    setSubmitting(true);
    try {
      const { data } = await updateTask(id, formData);
      setTask(data.task);
      toast.success('Task updated');
      setModalOpen(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setSubmitting(true);
    try {
      await deleteTask(id);
      toast.success('Task deleted');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navbar />
        <Loader label="Loading task..." />
      </div>
    );
  }

  if (!task) return null;

  const isOverdue = task.status !== 'Completed' && new Date(task.dueDate) < new Date();

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
        <Link to="/dashboard" className="mb-4 inline-flex items-center gap-1 text-sm font-medium text-brand-600 hover:underline">
          ← Back to Dashboard
        </Link>

        <div className="card p-6 sm:p-8">
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <h1 className="text-2xl font-bold text-slate-900">{task.title}</h1>
            <span className={`shrink-0 rounded-full border px-3 py-1 text-xs font-semibold ${priorityStyles[task.priority]}`}>
              {task.priority} priority
            </span>
          </div>

          <div className="mb-6 flex flex-wrap gap-2">
            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${statusStyles[task.status]}`}>
              {task.status}
            </span>
            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${isOverdue ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>
              {isOverdue ? '⚠ Overdue — ' : 'Due '}
              {new Date(task.dueDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
          </div>

          <div className="mb-6">
            <h2 className="mb-2 text-sm font-semibold text-slate-700">Description</h2>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-600">
              {task.description || 'No description provided.'}
            </p>
          </div>

          <div className="mb-6 grid grid-cols-2 gap-4 border-t border-slate-100 pt-4 text-xs text-slate-400">
            <div>
              <p className="font-medium text-slate-500">Created</p>
              <p>{new Date(task.createdAt).toLocaleString('en-IN')}</p>
            </div>
            <div>
              <p className="font-medium text-slate-500">Last Updated</p>
              <p>{new Date(task.updatedAt).toLocaleString('en-IN')}</p>
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={() => setModalOpen(true)} className="btn-primary">
              Edit Task
            </button>
            <button onClick={() => setConfirmOpen(true)} className="btn-danger">
              Delete Task
            </button>
          </div>
        </div>
      </main>

      <TaskModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleUpdate}
        initialData={task}
        submitting={submitting}
      />

      <ConfirmDialog
        isOpen={confirmOpen}
        title="Delete this task?"
        message={`"${task.title}" will be permanently removed. This action cannot be undone.`}
        onConfirm={handleDelete}
        onCancel={() => setConfirmOpen(false)}
        loading={submitting}
      />
    </div>
  );
};

export default TaskDetails;
