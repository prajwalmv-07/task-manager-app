const { validationResult } = require('express-validator');
const Task = require('../models/Task');
const asyncHandler = require('../middleware/asyncHandler');

// @route   POST /api/tasks
// @access  Private
const createTask = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg });
  }

  const { title, description, status, priority, dueDate } = req.body;

  const task = await Task.create({
    title,
    description,
    status,
    priority,
    dueDate,
    userId: req.user._id,
  });

  const io = req.app.get('io');
  if (io) io.to(String(req.user._id)).emit('task:created', task);

  res.status(201).json({ success: true, message: 'Task created', task });
});

// @route   GET /api/tasks
// @access  Private
// Supports: ?search=&status=&priority=&sortBy=dueDate|priority|createdAt&order=asc|desc&page=&limit=
const getTasks = asyncHandler(async (req, res) => {
  const { search, status, priority, sortBy, order, page = 1, limit = 50 } = req.query;

  const query = { userId: req.user._id };

  if (status && status !== 'All') query.status = status;
  if (priority && priority !== 'All') query.priority = priority;
  if (search) {
    query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
    ];
  }

  const sortField = ['dueDate', 'priority', 'createdAt', 'title'].includes(sortBy) ? sortBy : 'createdAt';
  const sortOrder = order === 'asc' ? 1 : -1;

  // Priority needs custom ordering (High > Medium > Low) rather than alphabetical
  let tasks;
  if (sortField === 'priority') {
    const priorityRank = { High: 3, Medium: 2, Low: 1 };
    tasks = await Task.find(query).lean();
    tasks.sort((a, b) => {
      const diff = priorityRank[a.priority] - priorityRank[b.priority];
      return sortOrder === 1 ? diff : -diff;
    });
  } else {
    tasks = await Task.find(query)
      .sort({ [sortField]: sortOrder })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));
  }

  const total = await Task.countDocuments(query);

  res.status(200).json({
    success: true,
    count: tasks.length,
    total,
    page: Number(page),
    tasks,
  });
});

// @route   GET /api/tasks/stats
// @access  Private
const getTaskStats = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const now = new Date();

  const [total, pending, inProgress, completed, overdue] = await Promise.all([
    Task.countDocuments({ userId }),
    Task.countDocuments({ userId, status: 'Pending' }),
    Task.countDocuments({ userId, status: 'In Progress' }),
    Task.countDocuments({ userId, status: 'Completed' }),
    Task.countDocuments({ userId, status: { $ne: 'Completed' }, dueDate: { $lt: now } }),
  ]);

  res.status(200).json({
    success: true,
    stats: { total, pending, inProgress, completed, overdue },
  });
});

// @route   GET /api/tasks/:id
// @access  Private
const getTask = asyncHandler(async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, userId: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found' });
  }
  res.status(200).json({ success: true, task });
});

// @route   PUT /api/tasks/:id
// @access  Private
const updateTask = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg });
  }

  let task = await Task.findOne({ _id: req.params.id, userId: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found' });
  }

  const allowedFields = ['title', 'description', 'status', 'priority', 'dueDate'];
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) task[field] = req.body[field];
  });

  await task.save();

  const io = req.app.get('io');
  if (io) io.to(String(req.user._id)).emit('task:updated', task);

  res.status(200).json({ success: true, message: 'Task updated', task });
});

// @route   DELETE /api/tasks/:id
// @access  Private
const deleteTask = asyncHandler(async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found' });
  }

  const io = req.app.get('io');
  if (io) io.to(String(req.user._id)).emit('task:deleted', { id: req.params.id });

  res.status(200).json({ success: true, message: 'Task deleted', id: req.params.id });
});

module.exports = { createTask, getTasks, getTaskStats, getTask, updateTask, deleteTask };
