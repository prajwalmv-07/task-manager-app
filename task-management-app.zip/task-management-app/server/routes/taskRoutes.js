const express = require('express');
const { body } = require('express-validator');
const {
  createTask,
  getTasks,
  getTaskStats,
  getTask,
  updateTask,
  deleteTask,
} = require('../controllers/taskController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect); // every task route requires authentication

const createValidation = [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('dueDate').notEmpty().withMessage('Due date is required').isISO8601().withMessage('Due date must be a valid date'),
  body('status').optional().isIn(['Pending', 'In Progress', 'Completed']).withMessage('Invalid status'),
  body('priority').optional().isIn(['Low', 'Medium', 'High']).withMessage('Invalid priority'),
];

const updateValidation = [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty'),
  body('dueDate').optional().isISO8601().withMessage('Due date must be a valid date'),
  body('status').optional().isIn(['Pending', 'In Progress', 'Completed']).withMessage('Invalid status'),
  body('priority').optional().isIn(['Low', 'Medium', 'High']).withMessage('Invalid priority'),
];

router.route('/').post(createValidation, createTask).get(getTasks);
router.get('/stats', getTaskStats);
router
  .route('/:id')
  .get(getTask)
  .put(updateValidation, updateTask)
  .delete(deleteTask);

module.exports = router;
