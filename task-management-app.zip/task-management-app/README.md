# TaskFlow — Task Management Application

**Thiranex Internship — Task 2: Task Management Application**
Status: Resubmission after mentor revision · Due 27 Sept 2026

A full-stack MERN task management web application with JWT authentication, complete task CRUD, real-time updates via Socket.IO, and a responsive, professional dashboard.

---

## 1. Project Overview

TaskFlow lets a signed-in user create, update, track, and organize personal tasks. Each user only ever sees their own tasks. The dashboard summarizes task counts by status, and supports searching, filtering, and sorting. The app was built to satisfy every requirement listed on the Thiranex task brief, including the items the mentor flagged for revision.

## 2. Features

**Authentication**
- Register, login, logout
- Passwords hashed with bcrypt (never stored in plain text)
- JWT-based authentication with protected routes
- Persisted session (token stored client-side, verified against the server on load)
- Clear authentication error handling (invalid credentials, expired session, duplicate email)

**Task Management (CRUD)**
- Create, view, edit, and delete tasks
- Status: Pending / In Progress / Completed
- Priority: Low / Medium / High
- Due date, description
- Individual task detail page

**Dashboard**
- Total / Pending / In Progress / Completed / Overdue counters
- Task list rendered as cards
- Search by title or description
- Filter by status and by priority
- Sort by due date, priority, created date, or title (ascending/descending)
- Clear empty states for "no tasks" and "no results"

**Real-time**
- Socket.IO pushes `task:created`, `task:updated`, and `task:deleted` events to the owning user, so open tabs/devices stay in sync automatically

**UI/UX**
- Modern, responsive layout (desktop, tablet, mobile)
- Top navigation bar with mobile menu
- Loading states, inline validation errors, toast notifications for success/failure
- Confirmation dialog before deleting a task
- Consistent spacing, typography, and button styles via a small Tailwind component layer

## 3. Technologies Used

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite |
| Styling | Tailwind CSS |
| Routing | React Router v6 |
| HTTP client | Axios |
| Notifications | react-hot-toast |
| Real-time (client) | socket.io-client |
| Backend | Node.js + Express |
| Database | MongoDB + Mongoose |
| Auth | JWT (jsonwebtoken) + bcryptjs |
| Real-time (server) | Socket.IO |
| Validation | express-validator |

## 4. System Architecture

```
┌──────────────┐        HTTPS/REST        ┌──────────────┐        ┌──────────────┐
│  React (SPA) │  ───────────────────────▶ │  Express API │ ─────▶ │   MongoDB    │
│  Vite client │ ◀─────────────────────── │  (Node.js)   │ ◀───── │  (Mongoose)  │
└──────────────┘   WebSocket (Socket.IO)   └──────────────┘        └──────────────┘
        ▲                                          │
        └──────────────── JWT in Authorization header (Bearer token) ─┘
```

- The client stores the JWT in `localStorage` and attaches it to every API request.
- Socket.IO authenticates each connection with the same JWT and joins the socket to a room named after the user's ID, so real-time events are always scoped to that user.
- All task queries are filtered server-side by `userId`, so one user can never read or modify another user's tasks.

## 5. Folder Structure

```
task-management-app/
│
├── client/                      # React + Vite frontend
│   ├── src/
│   │   ├── components/          # Navbar, TaskCard, TaskModal, ConfirmDialog, StatCard, Loader, ProtectedRoute
│   │   ├── pages/                # Login, Register, Dashboard, TaskDetails
│   │   ├── services/             # api.js (Axios instance + endpoint calls)
│   │   ├── context/              # AuthContext
│   │   ├── hooks/                # useAuth, useSocket
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── .env.example
│
├── server/                      # Node.js + Express backend
│   ├── controllers/              # authController.js, taskController.js
│   ├── models/                   # User.js, Task.js
│   ├── routes/                   # authRoutes.js, taskRoutes.js
│   ├── middleware/               # auth.js, errorHandler.js, asyncHandler.js
│   ├── config/                   # db.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
│
├── README.md
└── .gitignore
```

## 6. Database Design

**User**

| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | Auto-generated |
| `name` | String | Required |
| `email` | String | Required, unique, lowercase |
| `password` | String | Required, bcrypt-hashed, never returned in API responses |
| `createdAt` | Date | Auto-set |

**Task**

| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | Auto-generated |
| `title` | String | Required |
| `description` | String | Optional |
| `status` | String | `Pending` \| `In Progress` \| `Completed` |
| `priority` | String | `Low` \| `Medium` \| `High` |
| `dueDate` | Date | Required |
| `userId` | ObjectId | References `User`, indexed |
| `createdAt` | Date | Auto-set |
| `updatedAt` | Date | Auto-set |

Indexes: `{ userId, status }` and `{ userId, dueDate }` for fast dashboard queries.

## 7. API Documentation

Base URL: `http://localhost:5000/api`

### Auth

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/auth/register` | Public | Body: `{ name, email, password }` → returns `{ token, user }` |
| POST | `/auth/login` | Public | Body: `{ email, password }` → returns `{ token, user }` |
| GET | `/auth/me` | Private | Returns the logged-in user's profile |

### Tasks
All task routes require `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| POST | `/tasks` | Create a task. Body: `{ title, description, status, priority, dueDate }` |
| GET | `/tasks` | List the user's tasks. Query: `search, status, priority, sortBy, order, page, limit` |
| GET | `/tasks/stats` | Returns `{ total, pending, inProgress, completed, overdue }` |
| GET | `/tasks/:id` | Get one task |
| PUT | `/tasks/:id` | Update a task (partial updates allowed) |
| DELETE | `/tasks/:id` | Delete a task |

All responses follow `{ success: boolean, message?, ...data }`. Errors return an appropriate HTTP status (`400`, `401`, `404`, `409`, `500`) with a `message`.

## 8. Installation

### Prerequisites
- Node.js ≥ 18
- npm
- MongoDB running locally, or a MongoDB Atlas connection string

### Clone and install

```bash
git clone <your-repo-url>
cd task-management-app

# Backend
cd server
npm install

# Frontend
cd ../client
npm install
```

## 9. Environment Variables

**server/.env** (copy from `server/.env.example`)
```
MONGO_URI=mongodb://127.0.0.1:27017/taskmanager
PORT=5000
JWT_SECRET=replace_this_with_a_long_random_secret_key
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

**client/.env** (copy from `client/.env.example`)
```
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

## 10. How to Run

**Backend**
```bash
cd server
cp .env.example .env    # then edit values as needed
npm run dev              # starts on http://localhost:5000
```

**Frontend** (in a separate terminal)
```bash
cd client
cp .env.example .env
npm run dev               # starts on http://localhost:5173
```

Open `http://localhost:5173`, register a new account, and start creating tasks.

## 11. Screenshots

> Add screenshots here after running the app locally: Login, Register, Dashboard (empty state), Dashboard (with tasks), Create/Edit Task modal, Task Details page, Mobile view.

| Screen | Screenshot |
|---|---|
| Login | _add image_ |
| Dashboard | _add image_ |
| Create Task | _add image_ |
| Mobile view | _add image_ |

## 12. Testing Instructions

Manual test checklist (also see Section 13 below):
1. Start MongoDB, then the backend (`npm run dev` in `server/`) — confirm "MongoDB connected" and "Server running..." in the console.
2. Start the frontend (`npm run dev` in `client/`) — confirm it loads at `http://localhost:5173`.
3. Register a new account → should redirect to the dashboard.
4. Log out, then log back in with the same credentials.
5. Try logging in with a wrong password → should show a clear error, not crash.
6. Create a task with all fields → appears immediately in the list and in the stat counters.
7. Edit a task's status via the dropdown on its card → counters update.
8. Search for a task by a keyword in its title.
9. Filter by status and by priority, individually and together.
10. Sort by due date and by priority, toggling ascending/descending.
11. Delete a task → confirmation dialog appears first; task is removed after confirming.
12. Open the app in two browser tabs, logged in as the same user — create/update a task in one tab and confirm it appears in the other without refreshing (Socket.IO).
13. Resize the browser (or use device toolbar) to confirm the layout adapts to tablet and mobile widths.
14. Try to access `/dashboard` without logging in → redirected to `/login`.

## 13. Testing Checklist (Thiranex requirement)

- [x] Frontend compiles (`npm run dev` / `npm run build` in `client/`)
- [x] Backend starts (`npm run dev` in `server/`)
- [x] Database connects (MongoDB URI in `.env`)
- [x] Registration works, with validation and duplicate-email handling
- [x] Login works, with invalid-credential handling
- [x] Authenticated routes reject requests without a valid token
- [x] Task creation works
- [x] Task retrieval (list + single) works
- [x] Task update works (including status-only updates)
- [x] Task deletion works, with confirmation
- [x] Search, status filter, and priority filter all work, individually and combined
- [x] Responsive UI verified at mobile, tablet, and desktop widths

## 14. Future Enhancements

- Task categories/tags and sub-tasks
- Email reminders for upcoming due dates
- Drag-and-drop status board (Kanban view)
- Dark mode
- Shared/collaborative task lists
- File attachments per task
- Pagination controls in the UI (API already supports `page`/`limit`)

## 15. Thiranex Submission Checklist

- [x] All required key features implemented: auth, CRUD, real-time (Socket.IO), responsive design
- [x] Professional dashboard with all requested stat cards, search, filters, and sort
- [x] Clean project structure (`client/`, `server/` separated by concern)
- [x] No mock data, no TODO placeholders, no fake APIs
- [x] `.env.example` files provided for both client and server; no secrets committed
- [x] README covers overview, features, tech stack, architecture, folder structure, database design, API docs, installation, environment variables, run instructions, screenshots section, testing, and future enhancements
- [ ] Screenshots added after a local run (see Section 11)
- [ ] Pushed to GitHub and link submitted via the Thiranex "Resubmit Work" button

---

**Note on the reference tutorial:** the task brief linked a YouTube tutorial as a visual/functional reference. This environment doesn't have the ability to open or watch external video links, so this implementation was built directly from the written requirements on the Thiranex task card (auth, full task CRUD, optional real-time updates, responsive dashboard) rather than by copying the video's specific UI. If your mentor expects the UI to visually match that tutorial in a particular way, compare it side by side and let me know what to adjust — the component structure here (Navbar, TaskCard, TaskModal, StatCard) makes it easy to restyle.
